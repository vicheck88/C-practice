#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QString>
#include <QFileDialog>
#include <QProcess>
#include <QTimer>
#include <QThread>
#include <QTextStream>
#include <QListWidgetItem>
#include <QListWidget>
#include <QFile>
#include <QImage>
#include <QDir>
#include <QDirIterator>
#include "playlist.h"
#define TIMEOUT 300
#define WIDTH 400
#define HEIGHT 300


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MainWindow(QWidget *parent = 0);
    bool pause_flag;
    bool load_flag;
    bool loc_flag;
    int per;
    int song_total;
    int time_elapsed;

    int volume;
    char current_time[13];
    static QString file_loc;
    QString image_loc_jpg;
    QString image_loc_bmp;
    QString image_loc_png;
    QString image_loc;
    static bool add_flag;
    static bool delete_flag;
    static QString list_file_loc;
    static QStringList playtext;
    static QFile *file;
    QString message;
    QString total_time;
    QStringList args;
    QProcess *mplayer_proc;
    QTextStream *playlist;
    QTimer *time;
    QImage * image;
    QPixmap *buffer;
    PlayList * dlg;

    void play(void);
    void dialog_open();
    ~MainWindow();
    
private slots:
    void on_openButton_clicked();

    void on_playButton_clicked();

    void on_stopButton_clicked();

    void on_muteBox_clicked();

    void get_info();

    void timeup();

    void on_volumeBar_valueChanged(int value);

    void on_progressBar_sliderPressed();

    void on_progressBar_sliderReleased();

    void on_pauseButton_clicked();



    void on_nextButton_clicked();

    void on_beforeButton_clicked();

    void add_multi_process();
    void add_process();
    void delete_process();
    void item_select_process();
signals:
    void next_clicked();
    void before_clicked();
    void open_pressed();

private:
    Ui::MainWindow *ui;

};

#endif // MAINWINDOW_H
