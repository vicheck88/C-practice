#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "playlist.h"
#include <QDebug>

QString MainWindow::file_loc;
bool MainWindow::add_flag;
bool MainWindow::delete_flag;
QStringList MainWindow::playtext;
QString MainWindow::list_file_loc;
QFile * MainWindow::file;


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->muteBox->checkState();
    mplayer_proc = new QProcess;
    pause_flag=0;
    load_flag=0;
    loc_flag=0;
    total_time.clear();
    volume=30;
    ui->volumeBar->setValue(volume);
    args<<"none";
    song_total=0;
    time_elapsed=0;
    time=new QTimer;
    dlg=NULL;
    list_file_loc.clear();
    connect(time,SIGNAL(timeout()),this,SLOT(timeup()));
    connect(mplayer_proc,SIGNAL(readyReadStandardOutput()),this,SLOT(get_info()));
    ui->playList->setHidden(true);
    image_loc.clear();

}

MainWindow::~MainWindow()
{
    mplayer_proc->close();
    delete ui;
}



void MainWindow::on_openButton_clicked()
{
    file_loc.clear();
    playtext.clear();
    file_loc=QFileDialog::getOpenFileName(this,tr("Open Music"),"/mnt/nfs",tr("Music Files (*.mp3 *.wav *.b3u)"));
    if(!file_loc.isEmpty())
    {
        QDialog(parent);
        ui->playList->clear();
        PlayList::listnum=0;
        if(strcmp(file_loc.toStdString().c_str()+(file_loc.length()-3),"b3u"))
        {
            ui->playList->addItem(file_loc);
            PlayList::listnum=1;
            emit open_pressed();
        }
        else
        {
           list_file_loc=file_loc;
           file=new QFile;
           file->setFileName(list_file_loc);
           file->open(QIODevice::ReadWrite);
           QTextStream play(file);
           QString line;
           line=play.readLine();
           if(line.isNull()) return;
           while(!line.isNull())
           {
               playtext << line;
               line=play.readLine();
           };
           emit open_pressed();
           ui->playList->addItems(playtext);
           PlayList::listnum=playtext.size();

           file->close();
           delete file;
           file=NULL;
        }
        dialog_open();

        ui->playList->setCurrentRow(0);
        file_loc=ui->playList->currentItem()->text();
    }
}

void MainWindow::dialog_open()
{

    if(dlg==NULL)
    {
        dlg=new PlayList;
        dlg->show();
    }
    else
    {
        dlg->close();
        delete dlg;
        dlg = new PlayList;
        dlg->show();
    }
    connect(dlg,SIGNAL(add_pressed()),this,SLOT(add_process()));
    connect(dlg,SIGNAL(delete_pressed()),this,SLOT(delete_process()));
    connect(dlg,SIGNAL(item_clicked()),this,SLOT(item_select_process()));
    connect(dlg,SIGNAL(add_multi_pressed()),this,SLOT(add_multi_process()));
    connect(this,SIGNAL(next_clicked()),dlg,SLOT(nextbutton_clicked()));
    connect(this,SIGNAL(before_clicked()),dlg,SLOT(beforebutton_clicked()));
    connect(this,SIGNAL(open_pressed()),dlg,SLOT(openbutton_clicked()));
}

void MainWindow::add_process()
{
    ui->playList->insertItem(PlayList::index,PlayList::item);
}

void MainWindow::add_multi_process()
{

    ui->playList->insertItems(PlayList::index,playtext);
    printf("mainwindow size: %d\n",playtext.size());
}

void MainWindow::delete_process()
{
    qDeleteAll(ui->playList->selectedItems());
    ui->playList->setCurrentRow(PlayList::index);
}

void MainWindow::item_select_process()
{
    ui->playList->setCurrentRow(PlayList::index);
}



void MainWindow::play()
{
    if(load_flag)
    {
        time->stop();
        mplayer_proc->write("loadfile '");
        mplayer_proc->write(file_loc.toStdString().data());
        mplayer_proc->write("'\n");
    }
    else
    {
        char volume_value[3];
        sprintf(volume_value,"%d",volume);
        args.clear();
        args<<"-slave";
        args<<"-volume";
        args<< (const char *)volume_value;
        args<<"-srate";
        args<<"44100";
        args<<file_loc.toStdString().data();
        mplayer_proc->setProcessChannelMode(QProcess::MergedChannels);
        mplayer_proc->start("/mnt/nfs/mplayer",args);
    }
    file_loc=ui->playList->currentItem()->text();
    ui->musicLabel->setText(file_loc);


    QStringList name=file_loc.split(".");
    image_loc_bmp=image_loc_jpg=image_loc_png=name[0];
    name.clear();
    name=image_loc_bmp.split("/");
    image_loc_bmp=image_loc_jpg=image_loc_png=name[4];
    image_loc_bmp.append(".bmp");
    image_loc_jpg.append(".jpg");
    image_loc_png.append(".png");
//    printf("%s\n",image_loc_bmp.toStdString().c_str());
//    QStringList strFilters;

//     strFilters += image_loc_bmp;
//     strFilters += image_loc_jpg;

     QDirIterator iterDir("/mnt/nfs/test_contents/images", QDir::Files | QDir::NoSymLinks);

     while (iterDir.hasNext())
     {
         if(!iterDir.fileName().compare(image_loc_bmp) || !iterDir.fileName().compare(image_loc_jpg)
                 || !iterDir.fileName().compare(image_loc_png))
         {
             image_loc=iterDir.filePath();
             printf("%s\n",image_loc.toStdString().c_str());
             break;
         }
         iterDir.next();
     }
     if(!image_loc.isEmpty())
     {
         printf("not empty\n");
         image=new QImage;
         buffer = new QPixmap(image_loc);
         ui->imageLabel->setPixmap(*buffer);
         ui->imageLabel->resize((*buffer).width(),(*buffer).height());
//         image->load(image_loc);
//         buffer->fromImage(*image);
//         ui->imageLabel->setPixmap(*buffer);
//         ui->imageLabel->resize((*buffer).width(),(*buffer).height());

     }
     else ui->imageLabel->clear();

    load_flag=true;
    pause_flag=true;
    image_loc.clear();
    time->start(TIMEOUT);
    total_time.clear();
    time_elapsed=0;
}

void MainWindow::on_playButton_clicked()
{
    if(!file_loc.isNull())
    {
        //printf("path: %s",file_loc.toStdString().c_str());
        loc_flag=1;
        time->start(TIMEOUT);
        play();
    }

}

void MainWindow::on_stopButton_clicked()
{
    mplayer_proc->write("stop\n");
    ui->pauseButton->setText("Pause");
    ui->progressBar->setValue(0);
    load_flag=false;
    time->stop();
}

void MainWindow::on_muteBox_clicked()
{
    if(ui->muteBox->isChecked())
    {
        mplayer_proc->write("mute 1\n");
    }
    else
    {
        mplayer_proc->write("mute 0\n");
    }
}

void MainWindow::get_info()
{
    while(mplayer_proc->canReadLine())
    {
        message = mplayer_proc->readLine();
    }
}

void MainWindow::on_volumeBar_valueChanged(int value)
{
    QString c_value = QString::number(value,10);
    mplayer_proc->write("volume ");
    mplayer_proc->write(c_value.toLatin1().data());
    mplayer_proc->write(" 1\n");
    printf("volume: %d\n",value);
    ui->volumeBar->setValue(value);
    volume=value;
}

void MainWindow::timeup()
{
    QString new_message;
    QString current_time;
    char tot_time[13]={0};
    char cur_time[13]={0};
    float current;
    int cnt;
    bool ok;
    int total=0;

    if(load_flag)
    {
        time_elapsed++;
        if(time_elapsed<8)
        {
            mplayer_proc->write("get_time_length\n");
            new_message=message;
            printf("%s\n",new_message.toStdString().c_str());
            for(cnt = 0; cnt < new_message.length(); cnt++)
            {
                if(new_message[cnt] >= '0' && new_message[cnt] <= '9')
                    total_time.append(new_message[cnt]);
            }
            total=total_time.toInt(&ok);
            total/=100;
            //printf("total: %d\n",total);
            //printf("before solg_total: %d\n",song_total);
            if(total!=0)
            {
                sprintf(tot_time,"%02d : %02d : %02d",total/3600,(total%3600)/60,total%60);
                ui->totalLabel->setText(tot_time);
                song_total=total;
                //printf("before solg_total: %d\n",song_total);
            }
            total_time.clear();
        }
        else
        {
            //printf("time_elapsed: %d\n",time_elapsed);
            //printf("%d\n",song_total);
            mplayer_proc->write("get_time_pos\n");
            new_message = message;
            //printf("%s\n",new_message.toStdString().c_str());
            for(cnt = 0; cnt < new_message.length(); cnt++)
            {
                if(new_message[cnt] >= '0' && new_message[cnt] <= '9')
                    current_time.append(new_message[cnt]);
            }
            current=current_time.toFloat(&ok)/10;
            sprintf(cur_time,"%02d : %02d : %02d",(int)current/3600,((int)current%3600)/60,(int)current%60);

            per=(int)(current/song_total*100);
            ui->elapseLabel->setText(cur_time);
            ui->progressBar->setValue(per);
        }
    }
    if(mplayer_proc->state() == QProcess::NotRunning)
    {
        int pos;
        pos=PlayList::index;
        if(pos==PlayList::listnum-1)
        {
            loc_flag=false;
            load_flag=false;
            pause_flag=false;
            file_loc.clear();
            args.clear();
            ui->elapseLabel->setText("00 : 00 : 00");
            ui->totalLabel->setText("00 : 00 : 00");
            ui->progressBar->setValue(0);
            return;
        }
        load_flag=0;
        ui->playList->setCurrentRow(pos+1);
        file_loc=ui->playList->currentItem()->text();
        printf("file: %s\n",file_loc.toStdString().c_str());
        play();
    }
}


void MainWindow::on_progressBar_sliderPressed()
{
    if(load_flag==false) return;
    time->stop();
}


void MainWindow::on_progressBar_sliderReleased()
{
    if(load_flag==false) return;
    int position;
    position=ui->progressBar->value();
    QString c_value = QString::number(position,10);
    ui->progressBar->setSliderPosition(position);
    mplayer_proc->write("seek ");
    mplayer_proc->write(c_value.toLatin1().data());
    mplayer_proc->write(" 1\n");
    time->start(TIMEOUT);
    pause_flag = 0;
}

void MainWindow::on_pauseButton_clicked()
{
    if(pause_flag)
    {
        time->stop();
        ui->pauseButton->setText("Resume");
    }
    else
    {
        time->start(TIMEOUT);
        ui->pauseButton->setText("Pause");
    }
    pause_flag=!pause_flag;
    mplayer_proc->write("pause\n");
}

//void MainWindow::on_playList_itemClicked(QListWidgetItem *item)
//{
////    file_loc = item->text();
//}



void MainWindow::on_nextButton_clicked()
{
    int pos;
    pos=ui->playList->currentRow();
    if(pos==PlayList::listnum-1) return;
    PlayList::index=pos+1;
    ui->playList->setCurrentRow(PlayList::index);
    file_loc=ui->playList->currentItem()->text();
    //printf("file: %s\n",file_loc.toStdString().c_str());
    emit next_clicked();
    if(load_flag) play();
}

void MainWindow::on_beforeButton_clicked()
{
    int pos;
    pos=ui->playList->currentRow();
    if(!pos) return;
    PlayList::index=pos-1;
    ui->playList->setCurrentRow(PlayList::index);
    file_loc=ui->playList->currentItem()->text();
    //printf("file: %s\n",file_loc.toStdString().c_str());
    emit before_clicked();
    if(load_flag) play();
}

//void MainWindow::on_Add_clicked()
//{
////    file_loc.clear();
////    file_loc=QFileDialog::getOpenFileName(this,tr("Open Music"),"");
////    int pos=ui->playList->currentRow();
////    ui->playList->insertItem(pos,file_loc);
////    PlayList::listnum++;
//}

//void MainWindow::on_Delete_clicked()
//{
////    qDeleteAll(ui->playList->selectedItems());
////    if(ui->playList->currentRow()==PlayList::listnum-1) ui->playList->setCurrentRow(PlayList::listnum-2);
////    PlayList::listnum--;
//}

//void MainWindow::on_writeButton_clicked()
//{
////    int i;
////    file->setFileName(list_file_loc);
////    file->open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text);
////    QTextStream play(file);

////    for(i=0;i<PlayList::listnum;i++)
////    {
////        printf("%s\n",ui->playList->currentItem()->text().toStdString().c_str());
////        ui->playList->setCurrentRow(i);
////        play << ui->playList->currentItem()->text();
////        play << endl;
////    }
////    file->close();
//}
