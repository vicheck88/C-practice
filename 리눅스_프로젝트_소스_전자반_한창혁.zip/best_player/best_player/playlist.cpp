#include "playlist.h"
#include "ui_playlist.h"
#include "mainwindow.h"

int PlayList::index;
int PlayList::listnum;
QString PlayList::item;


PlayList::PlayList(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::PlayList)
{
    ui->setupUi(this);
    openbutton_clicked();
}

PlayList::~PlayList()
{
    delete ui;
    close();

}

void PlayList::openbutton_clicked()
{
    ui->playList->clear();

    if(MainWindow::playtext.isEmpty())
    {
        if(MainWindow::file_loc.isEmpty()) listnum=0;
        ui->playList->addItem(MainWindow::file_loc);
        listnum=1;
    }
    else
    {
       ui->playList->addItems(MainWindow::playtext);
       listnum=MainWindow::playtext.size();
    }
    ui->playList->setCurrentRow(0);
    index=0;
    printf("list ind: %d\n",listnum);
}


void PlayList::on_AddButton_clicked()
{
    MainWindow::file_loc.clear();
    MainWindow::playtext.clear();
    MainWindow::file_loc=QFileDialog::getOpenFileName(this,tr("Open Music"),"/mnt/nfs",tr("Music Files (*.mp3 *.wav *.b3u)"));
    if(MainWindow::file_loc.isNull()) return;

    index=ui->playList->currentRow();
    if(strcmp(MainWindow::file_loc.toStdString().c_str()+(MainWindow::file_loc.length()-3),"b3u"))
    {
        item = MainWindow::file_loc;
        ui->playList->insertItem(index,MainWindow::file_loc);
        listnum++;
        emit add_pressed();
    }
    else
    {

       MainWindow::list_file_loc=MainWindow::file_loc;
       MainWindow::file=new QFile;

       MainWindow::file->setFileName(MainWindow::list_file_loc);

       MainWindow::file->open(QIODevice::ReadWrite);
       printf("before\n");
       QTextStream play(MainWindow::file);

       QString line;
       line=play.readLine();
       while(!line.isNull())
       {
           MainWindow::playtext << line;
           line=play.readLine();
       };

       MainWindow::file->close();
       delete MainWindow::file;
       MainWindow::file=NULL;
       printf("after\n");
       ui->playList->insertItems(index,MainWindow::playtext);
       listnum+=MainWindow::playtext.size();
       emit add_multi_pressed();
       printf("size: %d\n",MainWindow::playtext.size());
    }
    MainWindow::file_loc=ui->playList->currentItem()->text();
}

void PlayList::on_DeleteButton_clicked()
{
    if(listnum==0) return;
    qDeleteAll(ui->playList->selectedItems());
    index=ui->playList->currentRow();
    if(index==listnum-1) ui->playList->setCurrentRow(--index);
    listnum--;
    emit delete_pressed();

}

void PlayList::on_writeButton_clicked()
{
    int i;
    if(MainWindow::list_file_loc.isEmpty())
        MainWindow::list_file_loc=QFileDialog::getOpenFileName(this,tr("Select playlistfiles to save"),"/mnt/nfs",tr("Music Files (*.b3u)"));
    //if(MainWindow::list_file_loc.isEmpty()) return;
    MainWindow::file=new QFile;
    MainWindow::file->setFileName(MainWindow::list_file_loc);
    printf("2. %s\n",MainWindow::list_file_loc.toStdString().c_str());
    MainWindow::file->open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text);
    printf("3. %s\n",MainWindow::list_file_loc.toStdString().c_str());
    QTextStream play(MainWindow::file);

    for(i=0;i<listnum;i++)
    {
        //printf("times: %d\n",i);
        //printf("list: %d\n",listnum);
        printf("%s\n",ui->playList->currentItem()->text().toStdString().c_str());
        ui->playList->setCurrentRow(i);
        play << ui->playList->currentItem()->text();
        play << endl;
    }
    MainWindow::file->close();
    delete MainWindow::file;
}

void PlayList::on_playList_itemClicked(QListWidgetItem *item)
{
    MainWindow::file_loc = item->text();
    index=ui->playList->currentRow();
    emit item_clicked();
}

void PlayList::on_closeButton_clicked()
{
    close();
}

void PlayList::nextbutton_clicked()
{
    //if(!load_flag) return;
//    int pos;
//    pos=ui->playList->currentRow();
//    if(pos==listnum-1) return;
    ui->playList->setCurrentRow(index);
//    MainWindow::file_loc=ui->playList->currentItem()->text();
    printf("file: %s\n",MainWindow::file_loc.toStdString().c_str());
}

void PlayList::beforebutton_clicked()
{
    //if(!load_flag) return;
    int pos;
    pos=ui->playList->currentRow();
    if(pos==0) return;
    ui->playList->setCurrentRow(index);
//    MainWindow::file_loc=ui->playList->currentItem()->text();
    printf("file: %s\n",MainWindow::file_loc.toStdString().c_str());
}
