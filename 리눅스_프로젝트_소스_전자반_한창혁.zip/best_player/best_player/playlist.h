#ifndef PLAYLIST_H
#define PLAYLIST_H

#include <QDialog>
#include <QMainWindow>
#include <QString>
#include <QFileDialog>
#include <QProcess>
#include <QTimer>
#include <QThread>
#include <QTextStream>
#include <QListWidgetItem>
#include <QListWidget>
#include <QFile>



namespace Ui {
class PlayList;
}

class PlayList : public QDialog
{
    Q_OBJECT
    
public:
    explicit PlayList(QWidget *parent = 0);
    static int index;
    char current_time[13];
    QTextStream play;
    //QFile * file;
    static int listnum;
    static QString item;
    ~PlayList();
    
private slots:
    void on_AddButton_clicked();

    void on_DeleteButton_clicked();

    void on_writeButton_clicked();

    void on_closeButton_clicked();

    void on_playList_itemClicked(QListWidgetItem *item);

    void nextbutton_clicked();
    void beforebutton_clicked();
    void openbutton_clicked();


signals:
    void add_pressed();
    void delete_pressed();
    void item_clicked();
    void add_multi_pressed();


private:
    Ui::PlayList *ui;
};

#endif // PLAYLIST_H
