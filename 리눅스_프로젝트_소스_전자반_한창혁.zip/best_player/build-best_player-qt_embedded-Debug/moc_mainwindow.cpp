/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created: Fri Nov 24 14:05:08 2017
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../best_player/mainwindow.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MainWindow[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      19,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: signature, parameters, type, tag, flags
      12,   11,   11,   11, 0x05,
      27,   11,   11,   11, 0x05,
      44,   11,   11,   11, 0x05,

 // slots: signature, parameters, type, tag, flags
      59,   11,   11,   11, 0x08,
      83,   11,   11,   11, 0x08,
     107,   11,   11,   11, 0x08,
     131,   11,   11,   11, 0x08,
     152,   11,   11,   11, 0x08,
     163,   11,   11,   11, 0x08,
     178,  172,   11,   11, 0x08,
     209,   11,   11,   11, 0x08,
     240,   11,   11,   11, 0x08,
     272,   11,   11,   11, 0x08,
     297,   11,   11,   11, 0x08,
     321,   11,   11,   11, 0x08,
     347,   11,   11,   11, 0x08,
     367,   11,   11,   11, 0x08,
     381,   11,   11,   11, 0x08,
     398,   11,   11,   11, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_MainWindow[] = {
    "MainWindow\0\0next_clicked()\0before_clicked()\0"
    "open_pressed()\0on_openButton_clicked()\0"
    "on_playButton_clicked()\0on_stopButton_clicked()\0"
    "on_muteBox_clicked()\0get_info()\0"
    "timeup()\0value\0on_volumeBar_valueChanged(int)\0"
    "on_progressBar_sliderPressed()\0"
    "on_progressBar_sliderReleased()\0"
    "on_pauseButton_clicked()\0"
    "on_nextButton_clicked()\0"
    "on_beforeButton_clicked()\0add_multi_process()\0"
    "add_process()\0delete_process()\0"
    "item_select_process()\0"
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        MainWindow *_t = static_cast<MainWindow *>(_o);
        switch (_id) {
        case 0: _t->next_clicked(); break;
        case 1: _t->before_clicked(); break;
        case 2: _t->open_pressed(); break;
        case 3: _t->on_openButton_clicked(); break;
        case 4: _t->on_playButton_clicked(); break;
        case 5: _t->on_stopButton_clicked(); break;
        case 6: _t->on_muteBox_clicked(); break;
        case 7: _t->get_info(); break;
        case 8: _t->timeup(); break;
        case 9: _t->on_volumeBar_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: _t->on_progressBar_sliderPressed(); break;
        case 11: _t->on_progressBar_sliderReleased(); break;
        case 12: _t->on_pauseButton_clicked(); break;
        case 13: _t->on_nextButton_clicked(); break;
        case 14: _t->on_beforeButton_clicked(); break;
        case 15: _t->add_multi_process(); break;
        case 16: _t->add_process(); break;
        case 17: _t->delete_process(); break;
        case 18: _t->item_select_process(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData MainWindow::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow,
      qt_meta_data_MainWindow, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MainWindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 19)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 19;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::next_clicked()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void MainWindow::before_clicked()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}

// SIGNAL 2
void MainWindow::open_pressed()
{
    QMetaObject::activate(this, &staticMetaObject, 2, 0);
}
QT_END_MOC_NAMESPACE
