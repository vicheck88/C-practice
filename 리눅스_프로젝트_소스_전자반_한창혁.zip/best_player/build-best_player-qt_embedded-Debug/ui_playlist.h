/********************************************************************************
** Form generated from reading UI file 'playlist.ui'
**
** Created: Fri Nov 24 15:44:46 2017
**      by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PLAYLIST_H
#define UI_PLAYLIST_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QListWidget>
#include <QtGui/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_PlayList
{
public:
    QListWidget *playList;
    QPushButton *writeButton;
    QPushButton *AddButton;
    QPushButton *DeleteButton;
    QPushButton *closeButton;

    void setupUi(QDialog *PlayList)
    {
        if (PlayList->objectName().isEmpty())
            PlayList->setObjectName(QString::fromUtf8("PlayList"));
        PlayList->resize(400, 300);
        PlayList->setBaseSize(QSize(0, 0));
        playList = new QListWidget(PlayList);
        playList->setObjectName(QString::fromUtf8("playList"));
        playList->setGeometry(QRect(10, 10, 281, 281));
        writeButton = new QPushButton(PlayList);
        writeButton->setObjectName(QString::fromUtf8("writeButton"));
        writeButton->setGeometry(QRect(302, 76, 80, 26));
        AddButton = new QPushButton(PlayList);
        AddButton->setObjectName(QString::fromUtf8("AddButton"));
        AddButton->setGeometry(QRect(302, 12, 80, 26));
        DeleteButton = new QPushButton(PlayList);
        DeleteButton->setObjectName(QString::fromUtf8("DeleteButton"));
        DeleteButton->setEnabled(true);
        DeleteButton->setGeometry(QRect(302, 44, 80, 26));
        closeButton = new QPushButton(PlayList);
        closeButton->setObjectName(QString::fromUtf8("closeButton"));
        closeButton->setGeometry(QRect(301, 109, 80, 26));

        retranslateUi(PlayList);

        QMetaObject::connectSlotsByName(PlayList);
    } // setupUi

    void retranslateUi(QDialog *PlayList)
    {
        PlayList->setWindowTitle(QApplication::translate("PlayList", "Dialog", 0, QApplication::UnicodeUTF8));
        writeButton->setText(QApplication::translate("PlayList", "Write", 0, QApplication::UnicodeUTF8));
        AddButton->setText(QApplication::translate("PlayList", "Add", 0, QApplication::UnicodeUTF8));
        DeleteButton->setText(QApplication::translate("PlayList", "Delete", 0, QApplication::UnicodeUTF8));
        closeButton->setText(QApplication::translate("PlayList", "Close", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class PlayList: public Ui_PlayList {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PLAYLIST_H
