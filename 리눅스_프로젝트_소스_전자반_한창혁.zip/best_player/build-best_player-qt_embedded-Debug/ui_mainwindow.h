/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created: Fri Nov 24 15:44:46 2017
**      by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QListWidget>
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QSlider>
#include <QtGui/QStatusBar>
#include <QtGui/QToolBar>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QSlider *progressBar;
    QSlider *volumeBar;
    QPushButton *openButton;
    QPushButton *playButton;
    QPushButton *stopButton;
    QPushButton *nextButton;
    QPushButton *beforeButton;
    QCheckBox *muteBox;
    QLabel *totalLabel;
    QLabel *elapseLabel;
    QPushButton *pauseButton;
    QListWidget *playList;
    QLabel *musicLabel;
    QLabel *imageLabel;
    QMenuBar *menuBar;
    QMenu *menuPlayer;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(670, 449);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        progressBar = new QSlider(centralWidget);
        progressBar->setObjectName(QString::fromUtf8("progressBar"));
        progressBar->setGeometry(QRect(30, 340, 491, 31));
        progressBar->setOrientation(Qt::Horizontal);
        volumeBar = new QSlider(centralWidget);
        volumeBar->setObjectName(QString::fromUtf8("volumeBar"));
        volumeBar->setGeometry(QRect(610, 320, 20, 71));
        volumeBar->setOrientation(Qt::Vertical);
        openButton = new QPushButton(centralWidget);
        openButton->setObjectName(QString::fromUtf8("openButton"));
        openButton->setGeometry(QRect(50, 10, 80, 26));
        playButton = new QPushButton(centralWidget);
        playButton->setObjectName(QString::fromUtf8("playButton"));
        playButton->setGeometry(QRect(50, 50, 81, 26));
        stopButton = new QPushButton(centralWidget);
        stopButton->setObjectName(QString::fromUtf8("stopButton"));
        stopButton->setGeometry(QRect(50, 130, 80, 26));
        nextButton = new QPushButton(centralWidget);
        nextButton->setObjectName(QString::fromUtf8("nextButton"));
        nextButton->setGeometry(QRect(50, 180, 80, 26));
        beforeButton = new QPushButton(centralWidget);
        beforeButton->setObjectName(QString::fromUtf8("beforeButton"));
        beforeButton->setGeometry(QRect(50, 220, 80, 26));
        muteBox = new QCheckBox(centralWidget);
        muteBox->setObjectName(QString::fromUtf8("muteBox"));
        muteBox->setGeometry(QRect(640, 350, 21, 21));
        totalLabel = new QLabel(centralWidget);
        totalLabel->setObjectName(QString::fromUtf8("totalLabel"));
        totalLabel->setGeometry(QRect(470, 370, 111, 20));
        elapseLabel = new QLabel(centralWidget);
        elapseLabel->setObjectName(QString::fromUtf8("elapseLabel"));
        elapseLabel->setGeometry(QRect(20, 370, 131, 16));
        pauseButton = new QPushButton(centralWidget);
        pauseButton->setObjectName(QString::fromUtf8("pauseButton"));
        pauseButton->setGeometry(QRect(50, 80, 81, 26));
        playList = new QListWidget(centralWidget);
        playList->setObjectName(QString::fromUtf8("playList"));
        playList->setGeometry(QRect(10, 10, 21, 21));
        musicLabel = new QLabel(centralWidget);
        musicLabel->setObjectName(QString::fromUtf8("musicLabel"));
        musicLabel->setGeometry(QRect(30, 275, 491, 21));
        imageLabel = new QLabel(centralWidget);
        imageLabel->setObjectName(QString::fromUtf8("imageLabel"));
        imageLabel->setGeometry(QRect(210, 10, 400, 300));
        MainWindow->setCentralWidget(centralWidget);
        imageLabel->raise();
        progressBar->raise();
        volumeBar->raise();
        openButton->raise();
        playButton->raise();
        stopButton->raise();
        nextButton->raise();
        beforeButton->raise();
        muteBox->raise();
        totalLabel->raise();
        elapseLabel->raise();
        pauseButton->raise();
        playList->raise();
        musicLabel->raise();
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 670, 23));
        menuPlayer = new QMenu(menuBar);
        menuPlayer->setObjectName(QString::fromUtf8("menuPlayer"));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        menuBar->addAction(menuPlayer->menuAction());

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0, QApplication::UnicodeUTF8));
        openButton->setText(QApplication::translate("MainWindow", "Open", 0, QApplication::UnicodeUTF8));
        playButton->setText(QApplication::translate("MainWindow", "Play", 0, QApplication::UnicodeUTF8));
        stopButton->setText(QApplication::translate("MainWindow", "Stop", 0, QApplication::UnicodeUTF8));
        nextButton->setText(QApplication::translate("MainWindow", "Next", 0, QApplication::UnicodeUTF8));
        beforeButton->setText(QApplication::translate("MainWindow", "Prev", 0, QApplication::UnicodeUTF8));
        muteBox->setText(QString());
        totalLabel->setText(QString());
        elapseLabel->setText(QString());
        pauseButton->setText(QApplication::translate("MainWindow", "Pause", 0, QApplication::UnicodeUTF8));
        musicLabel->setText(QString());
        imageLabel->setText(QString());
        menuPlayer->setTitle(QApplication::translate("MainWindow", "Player", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
